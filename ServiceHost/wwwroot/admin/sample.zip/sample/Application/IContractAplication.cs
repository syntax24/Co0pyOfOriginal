     
        OperationResult Active(long id);
        OperationResult DeActive(long id);
        OperationResult Sign(long id);
        OperationResult UnSign(long id);