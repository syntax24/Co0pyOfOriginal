

        public OperationResult Active(long id)
        {
            var opration = new OperationResult();
            var contract = _contractRepository.Get(id);
            if (contract == null)
                return opration.Failed("رکورد مورد نظر یافت نشد");

            contract.Active();

            _contractRepository.SaveChanges();
            return opration.Succcedded();
        }

        public OperationResult DeActive(long id)
        {
            var opration = new OperationResult();
            var contract = _contractRepository.Get(id);
            if (contract == null)
                return opration.Failed("رکورد مورد نظر یافت نشد");

            contract.DeActive();


            _contractRepository.SaveChanges();
            return opration.Succcedded();
        }